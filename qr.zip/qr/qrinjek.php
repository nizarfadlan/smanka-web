<?php
include "koneksi.php";

$injek=mysqli_query($kon, "select * from anggota");
while($e=mysqli_fetch_array($injek)){

$bulan='2020-01-23';
		
 $waktu='06:55:03';
$tgljam='2020-01-23 06:55:03';
				
				mysqli_query($kon, "INSERT INTO temp(id_anggota,tanggal_jam,tanggal,jam,bayangan) VALUES ('$e[id_anggota]','$tgljam', '$bulan' , '$waktu', '$waktu')") or die (mysqli_error($kon));

}
?>