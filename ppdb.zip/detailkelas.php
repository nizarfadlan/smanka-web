<?php

include "system/koneksi.php";

$password=md5($_POST['password']);

mysqli_query($kon, "INSERT INTO operator(nama,akses,user,password) VALUES ('$_POST[nama]', '$_POST[akses]', '$_POST[user]','$password')")or die ("Query Gagal ".mysqli_error());

echo "<script>;window.location='admin.php?bagian=kjhdaskjhaseuhfdas786asdasdgjhads678dasg'</script>";
?>