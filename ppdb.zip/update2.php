<?php
include "system/koneksi.php";



mysqli_query($kon, "update siswa set ayah='$_POST[ayah]', kerja_ayah='$_POST[kerja_ayah]', ibu='$_POST[ibu]',
 kerja_ibu='$_POST[kerja_ibu]', telepon_ortu='$_POST[telepon_ortu]', alamat_ortu='$_POST[alamat_ortu]' 
 , wali='$_POST[wali]', kerja_wali='$_POST[kerja_wali]', alamat_wali='$_POST[alamat_wali]'
 
 
 where no_ujian='$_POST[no_ujian]' ")
or die ("SQL Error: ".mysqli_error());


echo "<script>;window.location='code/siswa.php?user=$_POST[no_ujian]'</script>";






?>