<?php
include "system/koneksi.php";


header("Content-type: application/vnd-ms-excel");
 

header("Content-Disposition: attachment; filename=LaporanDaftarUlang.xls");
echo "
Laporan Peserta Didik 

<table border='1'>
<tr><th>No Pendaftaran</th><th>Nama</th><th>NISN</th><th>NIK</th><th>Jenis Kelamin</th><th>Tempat</th>
<th>Tanggal Lahir</th><th>Agama</th><th>Alamat Siswa</th><th>Anak ke</th><th>Status</th><th>Telepon Siswa</th>
<th>Asal Sekolah</th><th>Alamat Sekolah</th><th>NUN</th><th>Tahun Ijasah</th><th>Tahun SKHUN</th><th>Ayah</th>
<th>Ibu</th><th>Pekerjaan Ayah</th><th>Pekerjaan Ibu</th><th>Alamat Ortu</th><th>Telepon Ortu</th><th>Wali</th>
<th>Alamat Wali</th><th>Keterangan</th></tr>
";
$eko=mysqli_query($kon, "select * from siswa ");
while($ek=mysqli_fetch_array($eko)){
	if($ek['verifikasi']=='1'){
		$ket='Sudah Daftar Ulang';
	}else{
		$ket='Belum Daftar Ulang';
	}
	echo "
<tr><td>$ek[no_ujian]</td><td>$ek[nama]</td><td>'$ek[nisn]</td><td>'$ek[nik]</td><td>$ek[jk]</td><td>$ek[tempat]</td>
<td>$ek[tgl_lahir]</td>
<td>$ek[agama]</td><td>$ek[alamat_pd]</td><td>$ek[anak_ke]</td><td>$ek[status]</td><td>'$ek[telepon]</td>
<td>$ek[asal_sekolah]</td><td>$ek[alamat_sekolah]</td>
<td>$ek[nem]</td><td>$ek[tahun_ijasah]</td><td>$ek[tahun_skhun]</td><td>$ek[ayah]</td>
<td>$ek[ibu]</td><td>$ek[kerja_ayah]</td><td>$ek[kerja_ibu]</td>
<td>$ek[alamat_ortu]</td><td>'$ek[telepon_ortu]</td><td>$ek[wali]</td><td>$ek[alamat_wali]</td><td>$ket</td></tr>
";
}
echo "
</table>


";




?>