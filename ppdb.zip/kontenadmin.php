 <?php
 
 echo "
<div class='kolom11'>
 		";

 if($_GET[bagian]=='sderaser786re687rsrsfsd235525fw'){
	
	
echo"	 

<div class='card'>
					
                      <div class='card-header'>
                        <strong>Dashboard</strong>
                      </div>
					  
                <div class='card-body card-block'>

<a href='?bagian=sderaser786re687rsrsfsd235525fw'>
            <div class='col-lg-3 col-md-6'>
                <div class='social-box twitter'>
                    <i class='fa fa-home'></i>
                    <span>Dashboard</span>
                </div>
                <!--/social-box-->
            </div><!--/.col-->
</a>
<a href='?bagian=kjhdaskjhaseuhfdas786asdasdgjhads678dasg'>
            <div class='col-lg-3 col-md-6'>
                <div class='social-box linkedin'>
                    <i class='fa fa-users'></i>
                    <span>Operator</span>
                </div>
                <!--/social-box-->
            </div><!--/.col-->
</a>
<a href='?bagian=43534534vwfvs453vy5b36bwstgtw'>
            <div class='col-lg-3 col-md-6'>
                <div class='social-box google-plus'>
                    <i class='fa fa-user'></i>
                    <span>Verifikasi Siswa</span>
                </div>
                <!--/social-box-->
            </div><!--/.col-->
</a>
<a href='?bagian=soal'>
            <div class='col-lg-3 col-md-6'>
                <div class='social-box twitter2'>
                    <i class='fa fa-book'></i>
                   <span>Laporan</span>
                </div>
                <!--/social-box-->
            </div><!--/.col-->
</a>			

</div>
</div>
		
		 ";
 }
elseif($_GET['bagian']=='kjhdaskjhaseuhfdas786asdasdgjhads678dasg'){

echo"	 

  
    <link rel='stylesheet' href='css/datatable/dataTables.bootstrap.min.css'>
	
 <link rel='stylesheet' href='css/block.css'>
 
<div class='card'>
                    <div class='card-header'>
        	<i class='mr-2 fa fa-users'></i>
                        <strong class='card-title'>Daftar Operator</strong>
						
						
					<a href='#popup'>	 
                   <button type='button' class='btn btn-primary btn-sm float-right' id='tambah'><i class='fa fa-plus-square'></i> Tambah Operator
                        </button>
                   	</a>
						
                    </div>
                    <div class='card-body'>

                       
		  
		  
		  
		 <table id='bootstrap-data-table' class='table table-striped table-bordered'>
                    <thead>
				
			<tr><th>No</th><th>Nama Operator</th><th>Akses</th><th>Opsi</th></tr>
				</thead> 
				<tbody>";
			$asq=mysqli_query($kon, "select * from operator");
			$no=1;
			while($b=mysqli_fetch_array($asq)){
		if($b['akses']=='1'){
			$kode='Admin Sekolah';
		}else{
			$kode='Operator';
		}
			
 echo "
			<tr><td>$no</td><td>$b[nama]</td><td>$kode</td><td>
			
			<a href='#eko' data-toggle='terbang' data-id='$b[id_operator]' class='button' style='text-decoration:none;'><button type='button' class='btn btn-outline-primary btn-sm'><i class='fa fa-edit'></i>&nbsp Edit</button></a>
			<a href='#eko3' data-toggle='terbang' data-id='$b[id_operator]' class='button' style='text-decoration:none;'><button type='button' class='btn btn-outline-danger btn-sm'><i class='fa fa-trash-o'></i>&nbsp Hapus</button></a>
			
			
			
			</td></tr>";
			$no++;
			}

 echo "
			</tbody>   
            </table>
		
 		</div>
        </div>

<link rel='stylesheet' href='css/terbang.css'>

 <div class='terbang fade1' id='eko'>
        <div class='terbang-dialog'>
            <div class='terbang-content'>
                <div class='terbang-header'>
                    <button type='button' class='close' data-dismiss='terbang'>&times;</button>
                    <div class='card-header'> <strong> Edit Data Operator </strong> </div>
                </div>
                <div class='terbang-body'>
                    <div class='eko2'></div>
                </div>
                <div class='terbang-footer'>
                    <button type='button' class='btn btn-outline-danger btn-sm' data-dismiss='terbang'><i class='fa fa-sign-out'></i>Batal</button>
                </div>
            </div>
        </div>
    </div>

<div class='terbang fade1' id='eko3'>
        <div class='terbang-dialog'>
            <div class='terbang-content'>
                 <div class='terbang-body'>
                    <div class='eko4'></div>
			
                </div>
                
            </div>
        </div>
    </div>

		
<link rel='stylesheet' href='css/animate.css'>	


<div id='popup' class='gerak'>
<div class='window'>

<div class='col col-md-8'>
	<div class='card'>
                    <div class='card-header'>
        	<i class='mr-2 fa fa-users'></i>
                        <strong class='card-title'>Tambah Operator</strong>
                    </div>
                    <div class='card-body'>

                        
            
            
			
			
<form action='mesin.php' method='post' class='form-horizontal'>
                          

			   <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>Nama Operator</label></div>
                            <div class='col-12 col-md-9'><input type='text' id='text-input' name='nama'  class='form-control' required><small class='form-text text-muted'></small></div>
                          </div>


			 <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>Akses</label></div>
                           
						   <div class='col col-md-9'>
                              <div class='form-check'>
                                <div class='radio'>
                                  <label for='radio1' class='form-check-label '>
                                    <input type='radio' id='radio1' name='akses' value='1' class='form-check-input' required>Admin Sekolah
                                  </label>
                                </div>
                                <div class='radio'>
                                  <label for='radio2' class='form-check-label '>
                                    <input type='radio' id='radio2' name='akses' value='0' class='form-check-input'>Operator
                                  </label>
                                </div>
                             
                              </div>
						   
						  </div> 
						   
                          </div>

			
			   <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>User</label></div>
                            <div class='col-12 col-md-9'><input type='text' id='text-input' name='user'  class='form-control' required><small class='form-text text-muted'></small></div>
                          </div>
		
				
			   <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>password</label></div>
                            <div class='col-12 col-md-9'><input type='text' id='text-input' name='password'  class='form-control' required><small class='form-text text-muted'></small></div>
                          </div>

                     
		   
		   <div class='card-footer'>
                   <button type='submit' class='btn btn-primary btn-sm'><i class='fa fa-save'></i> Simpan
                        </button>
					<a href='?bagian=kjhdaskjhaseuhfdas786asdasdgjhads678dasg'>	
						<button type='button' class='btn btn-danger btn-sm'><i class='fa fa-times-circle'></i> Batal
                        </button></a>
                       </form>   
                      </div>		

 
                   
                   
			
			
			
	
</div>

			
			
 		
        </div> 
		</div> 

</div>
</div>

</div>

<script src='js/data-table/datatables.min.js'></script>
    <script src='js/data-table/dataTables.bootstrap.min.js'></script>
     <script src='js/data-table/datatables-init.js'></script>

    <script type='text/javascript'>
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
        } );
    </script> 
<script>
$('#tambah').click(function() {
    $('.gerak').addClass('animated fadeInDown');
});


</script>

<script type='text/javascript'>
    $(document).ready(function(){
        $('#eko').on('show.bs.terbang', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            $.ajax({
                type : 'post',
                url : 'editmesin.php',
                data :  'rowid='+ rowid,
                success : function(data){
                $('.eko2').html(data);
                }
            });
         });
    });

    $(document).ready(function(){
        $('#eko3').on('show.bs.terbang', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            $.ajax({
                type : 'post',
                url : 'hapus1.php',
                data :  'rowid='+ rowid,
                success : function(data){
                $('.eko4').html(data);
                }
            });
         });
    });

		


  </script>
    <script src='js/terbang.js' ></script>

		 ";


	
}
elseif($_GET['bagian']=='siswa'){

echo "

          <div class='breadcrumbs'>
           ";
			
if(isset($_POST['upload1'])){			
include "system/excel_reader2.php";


$data = new Spreadsheet_Excel_Reader($_FILES['fileexcel']['tmp_name']);
$hasildata = $data->rowcount($sheet_index=0);



for ($i=2; $i<=$hasildata; $i++)
{
  
  $no_ujian = $data->val($i,1); 
  $nisn = $data->val($i,2); 
  $nama1 = $data->val($i,3);
  $jk = $data->val($i,4);
  $tempat = $data->val($i,5); 
  $tgl_lahir = $data->val($i,6); 
  $alamat_pd = $data->val($i,7); 
  $asal_sekolah = $data->val($i,8); 
   $nik = $data->val($i,9); 
  $telepon = $data->val($i,10); 
  $nem = $data->val($i,11); 

 
 
$nama = mysqli_real_escape_string($kon, $nama1);

  $cekpeserta=mysqli_query($kon, "select*from siswa where no_ujian='$noujian' ");
  $ditemukan=mysqli_num_rows($cekpeserta);
  if($ditemukan>0){
  }else{

$query = "INSERT INTO siswa (no_ujian, nisn, nama, jk,tempat,tgl_lahir,alamat_pd,asal_sekolah,
nik, telepon, nem) VALUES     ('$no_ujian','$nisn','$nama','$jk', '$tempat', '$tgl_lahir', '$alamat_pd', 
'$asal_sekolah','$nik', '$telepon', '$nem')";
$hasil = mysqli_query($kon, $query);
  }
}			
if($hasil){
							echo "
							 <div class='col-sm-12'>
                			<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                  			 <span class='badge badge-pill badge-success'>Success</span> Data Siswa Berhasil di Upload.
                    		<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                       		 <span aria-hidden='true'>&times;</span>
                   			 </button>
                				</div>
           					 </div>
							";
							
						}else{
							echo "
							
							<div class='col-sm-12'>
                <div class='alert  alert-danger alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-danger'>Error</span> Gagal Upload Data Siswa!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
            </div> ";
						}
}
					
echo"
        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Upload Siswa</strong> Form
                      </div>
					  
					
					  
					  
                      <div class='card-body card-block'>
					  <form method='post' enctype='multipart/form-data' action='' class='form-horizontal'>
                  			<input name='upload1' value='upload1' hidden>			
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Upload Data Siswa berupa file excell 97-2003 (.xls)</label></div>
                            <div class='col-12 col-md-9'>
							
							<input  name='fileexcel' type='file' required>
							
							</div>
                          </div>
						  
						  
                          
                      </div>
                      <div class='card-footer'>
                        <button type='submit' class='btn btn-primary btn-sm'>
                          <i class='fa fa-upload'></i> Upload
                        </button>
                        </form>
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
}


elseif($_GET['bagian']=='43534534vwfvs453vy5b36bwstgtw'){

echo "

          <div class='breadcrumbs'>
           ";
if(isset($_POST['cari'])){			
include "system/koneksi.php";


$login1=mysqli_query($kon, "select * from siswa where no_ujian='$_POST[no_ujian]'");
		$ketemu1=mysqli_num_rows($login1);
		$e=mysqli_fetch_array($login1);
	if ($ketemu1>0){


echo "<script>;window.location='?bagian=ksfwr5q52352hdaskjhaseuhfdas786asdasdgjhads678dasg&hsfjhfs=$_POST[no_ujian]'</script>";								

							
						}else{
							echo "
							
							<div class='col-sm-12'>
                <div class='alert  alert-danger alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-danger'>Error</span> DATA SISWA TIDAK DITEMUKAN!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
            </div> ";
						}
}			

					
echo"
        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Verifikasi Siswa</strong> Form
                      </div>
			<div class='card-body card-block'> 
 <form method='post' enctype='multipart/form-data' action='' class='form-horizontal'>
     <input name='cari' value='cari' hidden>	 
	 
					<div class='row form-group'>
                            <div class='col col-md-6'>
                              <div class='input-group'>
                                <input type='text' id='input2-group2' name='no_ujian' placeholder='Masukkan No Ujian Nasional' class='form-control'>
                                <div class='input-group-btn'><button type='submit' class='btn btn-primary'>
                                    <i class='fa fa-search'></i> Search
                                  </button></div>
                              </div>
                            </div>
                          </div>			
			</div>		  
					  
                      
                      
                        </form>
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
}


elseif($_GET['bagian']=='ksfwr5q52352hdaskjhaseuhfdas786asdasdgjhads678dasg'){
	include "system/koneksi.php";
	include "system/tanggal2.php";
	$msql=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[hsfjhfs]' ");
	$ek=mysqli_fetch_array($msql);
echo "

          <div class='breadcrumbs'>
            
       

        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Verifikasi Siswa</strong>
                      </div>
                      <div class='card-body card-block'>
                        <form action='update1.php' method='post' class='form-horizontal' enctype='multipart/form-data'>
						<input type='text' name='no_ujian' value='$ek[no_ujian]' hidden>
						
						
						
						
						
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>No Ujian</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='sekolah' value='$ek[no_ujian]' class='form-control' disabled></div>
                          </div>
						  
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='sekolah' value='$ek[nama]' class='form-control' disabled></div>
     </div>	


	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>NISN</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='nisn' value='$ek[nisn]' class='form-control' disabled></div>
     </div>

	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>NIK</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='nik' value='$ek[nik]' class='form-control'></div>
     </div>
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tempat, Tgl Lahir</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='lahir' value='$ek[tempat], "; echo tanggalindo($ek[tgl_lahir]); echo "' class='form-control' disabled></div>
     </div>
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Jenis Kelamin</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='jk' value='$ek[jk]' class='form-control' disabled></div>
     </div>
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Asal Sekolah</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='asal_sekolah' value='$ek[asal_sekolah]' class='form-control' disabled></div>
     </div>
	 
	  <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Alamat Sekolah SMP/MTs.</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='alamat_sekolah' value='$ek[alamat_sekolah]' class='form-control'></div>
     </div>
	 

	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Nilai UN</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='nun' value='$ek[nem]' class='form-control' disabled></div>
     </div>
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Ekstra Wajib</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='ekstra1' value='$ek[ekstra1]' class='form-control' disabled></div>
     </div>
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Ekstra Pilihan</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='ekstra2' value='$ek[ekstra2]' class='form-control' disabled></div>
     </div>
	 
<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tahun Ijasah</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='tahun_ijasah' value='$ek[tahun_ijasah]' class='form-control'></div>
     </div>	
<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tahun SKHUN</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='tahun_skhun' value='$ek[tahun_skhun]' class='form-control'></div>
     </div>
	
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Alamat</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='alamat_pd' value='$ek[alamat_pd]' class='form-control'></div>
     </div>
	 
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Telepon</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='telepon' value='$ek[telepon]' class='form-control'></div>
     </div>
	 
	 
	 
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Agama</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='agama' value='$ek[agama]'  class='form-control'></div>
                          </div>
						  
						   <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Anak Ke</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='anak_ke' value='$ek[anak_ke]'  class='form-control'></div>
                          </div>
						  
						  
						  
						   <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Status Anak</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='status' value='$ek[status]' class='form-control'></div>
                          </div>
                       
                      </div>
                      <div class='card-footer'>
                        <button type='submit' class='btn btn-primary btn-sm'>
                          <i class='fa fa-save'></i> Lanjut
                        </button>
                        </form>
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
	
	
}

elseif($_GET['bagian']=='kjhdaskjhaseuhfdas5334534dfg45gf786asdasdgjhads678dasg'){
	include "system/koneksi.php";
	include "system/tanggal2.php";
	$msql=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[hsfjhfs]' ");
	$ek=mysqli_fetch_array($msql);
echo "

          <div class='breadcrumbs'>
            
       

        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Verifikasi Orang Tua / Wali Siswa</strong>
                      </div>
                      <div class='card-body card-block'>
                        <form action='update2.php' method='post' class='form-horizontal' enctype='multipart/form-data'>
						<input type='text' name='no_ujian' value='$ek[no_ujian]' hidden>
						
						
						
						
						
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama Ayah</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='ayah' value='$ek[ayah]' class='form-control'></div>
                          </div>
						  
						  
						  <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Pekerjaan Ayah</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='kerja_ayah' value='$ek[kerja_ayah]' class='form-control'></div>
                          </div>
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama Ibu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='ibu' value='$ek[ibu]' class='form-control' ></div>
     </div>	
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Pekerjaan Ibu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='kerja_ibu' value='$ek[kerja_ibu]' class='form-control'></div>
                          </div>


	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Telepon Ortu</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='telepon_ortu' value='$ek[telepon_ortu]' class='form-control'></div>
     </div>
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Alamat Ortu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='alamat_ortu' value='$ek[alamat_ortu]' class='form-control' ></div>
     </div>	
	 
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama Wali</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='wali' value='$ek[wali]' class='form-control' ></div>
     </div>	
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Pekerjaan Wali</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='kerja_wali' value='$ek[kerja_wali]' class='form-control'></div>
                          </div>


	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Alamat Wali </label></div>
      <div class='col-12 col-md-9'><input type='text'  name='alamat_wali' value='$ek[alamat_wali]' class='form-control'></div>
     </div>
	 
	 
	 
	 
	 
	 
	 
	 
                       
                      </div>
                      <div class='card-footer'>
                        <button type='submit' class='btn btn-primary btn-sm'>
                          <i class='fa fa-save'></i> Lanjut
                        </button>
                        </form>
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
	
	
}

elseif($_GET['bagian']=='65765ffjhvu68gig87guytyt'){
include "system/koneksi.php";
	include "system/tanggal2.php";
	
	
	$msql=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[tsdysdg]' ");
	$ek=mysqli_fetch_array($msql);
	$no_ujian=$ek['no_ujian'];
echo "

          <div class='breadcrumbs'>
          
		  
		  
        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Cetak Bukti Daftar Ulang</strong> 
                      </div>
			<div class='card-body card-block'> 
			
			
			
			
			<div class='row'>
				 <div class='col-sm-6'> 
				 					  
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama</label></div>
                            <div class='col-12 col-md-9'><label>: $ek[nama]</label></div>
     </div>	
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Asal Sekolah</label></div>
                            <div class='col-12 col-md-9'><label>: $ek[asal_sekolah]</label></div>
     </div>
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Alamat</label></div>
                            <div class='col-12 col-md-9'><label>: $ek[alamat_pd]</label></div>
     </div>

				 </div>
				  <div class='col-sm-6'>
				  
				  <a href='cetak.php?user=$no_ujian' target='_blank'>	
						<button type='button' class='btn btn-primary btn-sm'><i class='fa fa-print'></i> Cetak Bukti
                        </button></a>
				  
				  
				  
				  </div>
			</div>
			
			
			
			
			
			
			
			
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
}

elseif($_GET['bagian']=='fskdjfsdkfsfskjbsdff'){

echo "

          <div class='breadcrumbs'>
           ";
if(isset($_POST['cari'])){			
include "system/koneksi.php";


$login1=mysqli_query($kon, "select * from siswa where no_ujian='$_POST[no_ujian]'");
		$ketemu1=mysqli_num_rows($login1);
		$e=mysqli_fetch_array($login1);
	if ($ketemu1>0){


echo "<script>;window.location='?bagian=65765ffjhvu68gig87guytyt&tsdysdg=$_POST[no_ujian]'</script>";								

							
						}else{
							echo "
							
							<div class='col-sm-12'>
                <div class='alert  alert-danger alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-danger'>Error</span> DATA SISWA TIDAK DITEMUKAN!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
            </div> ";
						}
}			

					
echo"
        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Cetak Verifikasi Siswa</strong>
                      </div>
			<div class='card-body card-block'> 
 <form method='post' enctype='multipart/form-data' action='' class='form-horizontal'>
     <input name='cari' value='cari' hidden>	 
	 
					<div class='row form-group'>
                            <div class='col col-md-6'>
                              <div class='input-group'>
                                <input type='text' id='input2-group2' name='no_ujian' placeholder='Masukkan No Ujian Nasional' class='form-control'>
                                <div class='input-group-btn'><button type='submit' class='btn btn-primary'>
                                    <i class='fa fa-search'></i> Search
                                  </button></div>
                              </div>
                            </div>
                          </div>			
			</div>		  
					  
                      
                      
                        </form>
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
}



elseif($_GET['bagian']=='jhsdfkjshdkasjdhaksjd'){

echo "

          <div class='breadcrumbs'>
        
        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Laporan Daftar Ulang</strong>
                      </div>
			<div class='card-body card-block'> 

	 
					<div class='row form-group'>
                            <div class='col col-md-6'>
                              <div class='input-group'>
							  <a href='excel1.php'>
                                <button type='button' class='btn btn-primary'>
                                    <i class='fa fa-table'></i> Download Semua Calon Siswa
                                  </button></a>
                              </div>
                            </div>
                          </div>			
			
<div class='row form-group'>
                            <div class='col col-md-6'>
                              <div class='input-group'>
							  <a href='excel.php'>
                                <button type='button' class='btn btn-primary'>
                                    <i class='fa fa-table'></i> Download Sudah Daftar Ulang
                                  </button></a>
                              </div>
                            </div>
                          </div>			
			</div>				
					  
                      
                   
                      </div>
                    </div>

        </div>
    </div>
	</div>
	";	
}

?>
