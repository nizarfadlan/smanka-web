<?php

session_start();
unset($_SESSION['user']);
unset($_SESSION['password']);
unset($_SESSION['akses']);
session_destroy();


echo "<script>;window.location='admin/index.php'</script>";

?>
