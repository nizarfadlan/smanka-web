<?php
include "system/koneksi.php";

$ayah1 = mysqli_real_escape_string($kon, $_POST['ayah']);
$ibu1 = mysqli_real_escape_string($kon, $_POST['ibu']);
$wali1 = mysqli_real_escape_string($kon, $_POST['wali']);

mysqli_query($kon, "update siswa set ayah='$ayah1', kerja_ayah='$_POST[kerja_ayah]', ibu='$ibu1',
 kerja_ibu='$_POST[kerja_ibu]', telepon_ortu='$_POST[telepon_ortu]', alamat_ortu='$_POST[alamat_ortu]' 
 , wali='$wali1', kerja_wali='$_POST[kerja_wali]', alamat_wali='$_POST[alamat_wali]',nik_ayah='$_POST[nik_ayah]',nik_ibu='$_POST[nik_ibu]'
 
 
 where no_ujian='$_POST[no_ujian]' ")
or die ("SQL Error: ".mysqli_error());


echo "<script>;window.location='code/siswa1.php?user=$_POST[no_ujian]'</script>";






?>