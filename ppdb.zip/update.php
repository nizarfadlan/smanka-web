<?php
include "system/koneksi.php";

$password=md5($_POST[password]);

mysqli_query($kon, "update operator set nama='$_POST[nama]', akses='$_POST[akses]', user='$_POST[user]', password='$password' where id_operator='$_POST[id]' ")
or die ("SQL Error: ".mysqli_error());


echo "<script>;window.location='admin.php?bagian=kjhdaskjhaseuhfdas786asdasdgjhads678dasg'</script>";






?>