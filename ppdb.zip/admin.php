<?php
include "system/koneksi.php";


echo"

 <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>CPanel</title>
    <meta name='description' content='Eko Timo'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>

    <link rel='apple-touch-icon' href='apple-icon.png'>
    <link rel='shortcut icon' href='favicon.ico'>

    <link rel='stylesheet' href='css/normalize.css'>
    <link rel='stylesheet' href='css/bootstrap.css'>
    <link rel='stylesheet' href='css/font-awesome.min.css'>
    <link rel='stylesheet' href='css/style.css'> ";
echo "


<script type='text/javascript'>
    window.history.forward();
    function noBack(){ window.history.forward(); }
</script>

";
error_reporting(0);

session_start();

  
  $user=$_SESSION['user'];
  $akses=$_SESSION['akses'];
  $password=$_SESSION['password'];
  
$wsql=mysqli_query($kon, "select * from operator where user='$user' ");
$go=mysqli_fetch_array($wsql);

if (empty($_SESSION[user]) AND empty($_SESSION[password])){
  echo "
						
						
						
						    <div class='col-sm-12'>
                <div class='alert  alert-danger alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-danger'>Gagal</span> Anda Tidak Bisa Akses Halaman Ini Tanpa Login!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
            </div>
			<div class='col-sm-12'>
			<div class='card-footer'><a href='admin/index.php'>
                        <button type='button' class='btn btn-primary btn-block'>
                          <i class='fa fa-dot-circle-o'></i> Login
                        </button></a>
						

						";
}
else{
	echo "
	<!-- Left Panel -->
    <aside id='left-panel' class='left-panel'>
        <nav class='navbar navbar-expand-sm navbar-default'>

            <div class='navbar-header'>
                <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#main-menu' aria-controls='main-menu' aria-expanded='false' aria-label='Toggle navigation'>
                    <i class='fa fa-bars'></i>
                </button>
                <a class='navbar-brand' href='./'><img src='asset/logo.png' alt='Logo' width='70px'></a>
                <a class='navbar-brand hidden' href='./'><img src='asset/logo.png' alt='Logo'></a>
				
            </div> 
			
            <div id='main-menu' class='main-menu collapse navbar-collapse'>
                <ul class='nav navbar-nav'> 
				 <h3 class='menu-title'>$go[nama]</h3>
				
				";
				
	if($akses==1){
		$menu=mysqli_query($kon, "select * from menu order by id_menu ASC");
	while($ed=mysqli_fetch_array($menu)){
		echo " 
		<li>
                        <a href='$ed[link]'>$ed[ikon]</i>$ed[nama_menu] </a>
                    </li>
	";
	}	
	}else{
$menu=mysqli_query($kon, "select * from menu where kode_akses='$akses' order by id_menu ASC");

while($ed=mysqli_fetch_array($menu)){
		echo " 
		<li>
                        <a href='$ed[link]'>$ed[ikon]</i>$ed[nama_menu] </a>
                    </li>
	";
	}


	}
echo "
        
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id='right-panel' class='right-panel'>

       <div class='col-sm-12 hitam'>

                <div class='col-sm-1'>
                    <a id='menuToggle' class='menutoggle pull-left'><i class='fa fa fa-tasks'></i></a>
                 </div>
				<div class='col-sm-6 float-left putih'>
				<div class='qq'>$ek[nama_sekolah]</div><div class='rr'>$ek[alamat]</div>
				
				</div>
				
				
				
			
			
				
					
				
                <div class='col-sm-5'>
                    <div class='user-area dropdown float-right'>
                        <a href='#' class='dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                            <img class='user-avatar rounded-circle' src='asset/logo.png' alt='User Avatar'>
                        </a>

                        <div class='user-menu dropdown-menu'>

                                <a class='nav-link' href='?bagian=password'><i class='fa fa-unlock'></i> &nbsp Ubah Password</a>

                                <a class='nav-link' href='cpanel/index.php'><i class='fa fa-sign-out -off'></i> &nbsp Logout</a>
                        </div>
                    </div>

                  
                </div>
		</div>

    

        <div class='content mt-3'> ";
		
	   
		include "kontenadmin.php";
		   
	echo "	   
        </div>


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


	<script src='js/jquery-3.2.1.min.js'></script>
	<script src='js/popper.min.js'></script>
    <script src='js/plugins.js'></script>
	<script src='js/main1.js'></script>
	

<script>
object.onload = 'document.body.requestFullscreen()'
     
</script>

	<script src='js/bootstrap.js' ></script>

   
";

}


?>

