<?php
include "system/koneksi.php";

$password=md5($_POST[password]);

mysqli_query($kon, "update siswa set nik='$_POST[nik]', alamat_sekolah='$_POST[alamat_sekolah]', tahun_ijasah='$_POST[tahun_ijasah]',
 tahun_skhun='$_POST[tahun_skhun]', alamat_pd='$_POST[alamat_pd]', telepon='$_POST[telepon]' 
 , agama='$_POST[agama]', anak_ke='$_POST[anak_ke]', status='$_POST[status]'
 
 
 where no_ujian='$_POST[no_ujian]' ")
or die ("SQL Error: ".mysqli_error());


echo "<script>;window.location='admin.php?bagian=kjhdaskjhaseuhfdas5334534dfg45gf786asdasdgjhads678dasg&hsfjhfs=$_POST[no_ujian]'</script>";






?>