<?php
	include "system/koneksi.php";
	include "system/tanggal2.php";
	$msql=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[hsfjhfs]' ");
	$ek=mysqli_fetch_array($msql);
echo "
 <head>
    <!-- Required meta tags -->
    <meta charset='utf-8' />
    <meta
      name='viewport'
      content='width=device-width, initial-scale=1, shrink-to-fit=no'
    />
    <link rel='icon' href='img/favicon.png' type='image/png' />
    <title>SMANKA</title>
     <link rel='stylesheet' href='csss/bootstrap.css' />
    <link href='css/datepicker.css' rel='stylesheet'>
    <link rel='stylesheet' href='csss/style.css' />
	<link rel='stylesheet' href='css/font-awesome.min.css'>
  </head>
  <script type='text/javascript' src='js/jquery-3.2.1.min.js'></script> 
<script>
$(document).ready(function() {
	$('#kelas').change(function() { // Jika Select Box id provinsi dipilih
		var eko = $(this).val(); // Ciptakan variabel provinsi
		$.ajax({
			type: 'POST', // Metode pengiriman data menggunakan POST
			url: 'ekstra.php', // File yang akan memproses data
			data: 'kirim=' + eko, // Data yang akan dikirim ke file pemroses
			success: function(response) { // Jika berhasil
				$('.kelas').html(response); // Berikan hasil ke id kota
			}
		});
    });
});
</script>
  <body>
   
    <!--================Home Banner Area =================-->
    <section class='banner_area'>
      <div class='banner_inner d-flex align-items-center'>
        <div class='overlay'></div>
        <div class='container'>
          <div class='row justify-content-center'>
            <div class='col-lg-6'>
              <div class='banner_content text-center'>
               
                <div class='page_link'>
                 
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class='about_area section_gap'>
      <div class='container'>
        <div class='row h_blog_item'>
          
          
		  
	


            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Data Siswa</strong>
                      </div>
                      <div class='card-body card-block'>
                        <form action='update3.php' method='post' class='form-horizontal' enctype='multipart/form-data'>
						<input type='text' name='no_ujian' value='$ek[no_ujian]' hidden>
						
						
						
						
						
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>No Peserta</label></div>
                            <div class='col-12 col-md-9'><label>$ek[no_ujian]</label></div>
                          </div>
						  
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama</label></div>
                            <div class='col-12 col-md-9'><label>$ek[nama]</label></div>
     </div>	


	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>NISN</label></div>
      <div class='col-12 col-md-9'><label>$ek[nisn]</label></div>
     </div>

	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>NIK</label></div>
      <div class='col-12 col-md-9'><label>$ek[nik]</label></div>
     </div>
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tempat Lahir</label></div>
      <div class='col-12 col-md-9'><label>$ek[tempat]</label></div>
     </div>
     
     <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tanggal Lahir</label></div>
      
	 
	 <div class='col-12 col-md-3'>
                 

				 
               <div class='input-group date ' data-date='' data-date-format='yyyy-mm-dd'>
			   <span class='input-group-addon'><i class='fa fa-calendar'></i></span>
	                <input class='form-control' type='text' name='lahir' readonly required value='$ek[tgl_lahir]'> 
	          
            </div>
			
			</div>
                </div>
	 
	 
     
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Jenis Kelamin</label></div>
      <div class='col-12 col-md-9'><label>$ek[jk]</label></div>
     </div>
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Asal Sekolah</label></div>
      <div class='col-12 col-md-9'><label>$ek[asal_sekolah]</label></div>
     </div>
	 
	  <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Alamat Sekolah SMP/MTs.</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='alamat_sekolah' value='$ek[alamat_sekolah]' class='form-control'></div>
     </div>
	 

	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Nilai UN</label></div>
      <div class='col-12 col-md-9'><label>$ek[nem]</label></div>
     </div>
	 
	 
	 
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Kelas</label></div>
                            <div class='col-12 col-md-3'>
						
						
						<select name='kelas' id='select' class='form-control'>
							<option value=''>Pilih Kelas</option>";
							$pilih=$ek['kelas'];
							$kelasnya=mysqli_query($kon, "select * from kelas ");
							while ($h=mysqli_fetch_array($kelasnya)){
								
								if($pilih==$h['kelas']){ $op1='selected';}else{$op1='';}
echo "								
                             
							<option value='$h[kelas]' $op1>$h[kelas]</option>
								";
							}
							echo "
								 
								
                               
                              </select>
							
							
							</div>
                          </div>
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Ekstra Wajib</label></div>
      <div class='col-12 col-md-9'><label>Pendidikan Kepramukaan</label></div>
     </div> ";
	 $pilihan=mysqli_query($kon, "select * from ekstra");
	 
	
	 echo"
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Ekstra Pilihan</label></div>
		<div class='col-12 col-md-8'>
				

                                  <select   id='kelas' class='form-control' name='ekstra' required>
                                    <option value=''>Pilih Ekstra</option> ";
									$pilih=$ek['ekstra2'];
									while($er=mysqli_fetch_array($pilihan)){
										if($pilih==$er['nama_ekstra']){ $op1='selected';}else{$op1='';}
										
										echo " 
										<option value='$er[nama_ekstra]' $op1>$er[nama_ekstra]</option> ";
									}
									echo "
                                   
								   
								   
								   
                                </select>
                           
	  
		
		<div class='col-12 col-md-12'><br>
		 <div class='kelas'></div>
		 </div>
		 </div>
     </div>
	 
<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tahun Ijasah</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='tahun_ijasah' value='$ek[tahun_ijasah]' class='form-control'></div>
     </div>	
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Nomer Ijasah</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='no_ijasah' value='$ek[no_ijasah]' class='form-control' >
	  <div class='small'> Contoh DN-03  ada dibingkai paling bawah ijasah, kalau MTs kodenya MTs. </div>
	  </div>
	  
     </div>	
<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Tahun SKHUN</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='tahun_skhun' value='$ek[tahun_skhun]' class='form-control' >
	    <div class='small'> Contoh DN-03  ada dibingkai paling bawah SKHUN yg diterbitkan negara bukan yg kode Mts.</div></div>
     </div>
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Nomer SKHUN</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='no_skhun' value='$ek[no_skhun]' class='form-control'></div>
     </div>
	
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Alamat</label></div>
      <div class='col-12 col-md-9'><label>$ek[alamat_pd]</label></div>
     </div>
	 
	 
	 <div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Telepon</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='telepon' value='$ek[telepon]' class='form-control'></div>
     </div>
	 
	 
	 
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Agama</label></div>
                            <div class='col-12 col-md-3'>
							<select class='form-control' name='agama' required> ";
							$pilihagama=$ek['agama'];
							if($pilihagama=='Islam'){ $op2='selected';}else{$op2='';}
							if($pilihagama=='Katolik'){ $op3='selected';}else{$op3='';}
							if($pilihagama=='Kristen'){ $op4='selected';}else{$op4='';}
							if($pilihagama=='Hindu'){ $op5='selected';}else{$op5='';}
							if($pilihagama=='Budha'){ $op6='selected';}else{$op6='';}
							echo "
                                    <option value=''>Pilih Agama</option> 
										<option value='Islam' $op2>Islam</option>
<option value='Katolik' $op3>Katolik</option>
<option value='Kristen' $op4>Kristen</option>
<option value='Hindu' $op5>Hindu</option>
<option value='Budha' $op6>Budha</option>										
								   
                                </select>
							
							
							</div>
                          </div>
						  
						   <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Anak Ke</label></div>
                            <div class='col-12 col-md-3'><input type='text'  name='anak_ke' value='$ek[anak_ke]'  class='form-control' required></div>
                          </div>
						  
						  
						  
						   <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Status Anak</label></div>
                            <div class='col-12 col-md-3'>
							
							<select class='form-control' name='status' required>";
							$pilihstatus=$ek['status'];
							if($pilihstatus=='Anak Kandung'){ $op7='selected';}else{$op7='';}
							if($pilihstatus=='Anak Asuh'){ $op8='selected';}else{$op8='';}
							echo "
                                    <option value=''>Pilih Status</option> 
										<option value='Anak Kandung' $op7>Anak Kandung</option>
<option value='Anak Asuh' $op8>Anak Asuh</option>

                                </select>
							
							</div>
                          </div>
                       
                      </div>
                      <div class='card-footer'>
                        <button type='submit' class='btn btn-primary btn-sm'>
                          <i class='fa fa-save'></i> Lanjut
                        </button>
                        </form>
                      </div>
                    </div>

        </div>

  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
        </div>
      </div>
    </section>
    <!--================ End About Area =================-->

  </body>
  
  <script src='js/bootstrap-datepicker.js'></script>
    <script>
    $('.input-group.date').datepicker({autoclose: true, todayHighlight: true});
    </script>
  
  
  ";





?>