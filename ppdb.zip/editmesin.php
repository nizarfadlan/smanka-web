<?php
include "system/koneksi.php";
 $id = $_POST['rowid'];
 
 $swq=mysqli_query($kon, "select * from operator where id_operator='$id'");
 $r=mysqli_fetch_array($swq);
 if($r['akses']=='1'){
	 $op1='checked';
	 $op2='';
 }else{
	 $op2='checked';
	 $op1='';
 }
  echo " 
   <form action='update.php' method='post' class='form-horizontal'>
   <input type='text' name='id' hidden value='$id'>  
  
<input type='text' id='text-input' name='id_anggota'  class='form-control' value='$r[id_operator]' hidden>

			   <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>Nama Operator</label></div>
                            <div class='col-12 col-md-9'><input type='text' id='text-input' name='nama'  class='form-control' value='$r[nama]' required><small class='form-text text-muted'></small></div>
                          </div>


			 <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>Akses</label></div>
                           
						   <div class='col col-md-9'>
                              <div class='form-check'>
                                <div class='radio'>
                                  <label for='radio1' class='form-check-label '>
                                    <input type='radio' id='radio1' $op1 name='akses' value='1' class='form-check-input' required>Admin Sekolah
                                  </label>
                                </div>
                                <div class='radio'>
                                  <label for='radio2' class='form-check-label '>
                                    <input type='radio' id='radio2' $op2 name='akses' value='0' class='form-check-input'>Operator
                                  </label>
                                </div>
                             
                              </div>
						   
						  </div> 
						   
                          </div>

			
			   <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>User</label></div>
                            <div class='col-12 col-md-9'><input type='text' id='text-input' name='user'  class='form-control' value='$r[user]' required><small class='form-text text-muted'></small></div>
                          </div>
		
				
			   <div class='row form-group'>
                            <div class='col col-md-3'><label for='text-input' class=' form-control-label'>password</label></div>
                            <div class='col-12 col-md-9'><input type='text' id='text-input' name='password'  class='form-control' required><small class='form-text text-muted'></small></div>
                          </div>
		   
		   
		   
		   
		   
		   
		   <div class='card-footer'>
                   <button type='submit' class='btn btn-primary btn-sm'><i class='fa fa-save'></i> Simpan
                        </button>
					
                       </form>   
                      </div>
					  
      
";
?>