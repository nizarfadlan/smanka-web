<?php

echo "
 <head>
    <!-- Required meta tags -->
    <meta charset='utf-8' />
    <meta
      name='viewport'
      content='width=device-width, initial-scale=1, shrink-to-fit=no'
    />
    <link rel='icon' href='img/favicon.png' type='image/png' />
    <title>SMANKA</title>
     <link rel='stylesheet' href='csss/bootstrap.css' />
    
    <link rel='stylesheet' href='csss/style.css' />
  </head>

  <body>
   
    <!--================Home Banner Area =================-->
    <section class='banner_area'>
      <div class='banner_inner d-flex align-items-center'>
        <div class='overlay'></div>
        <div class='container'>
          <div class='row justify-content-center'>
            <div class='col-lg-6'>
              <div class='banner_content text-center'>
               
                <div class='page_link'>
                 
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class='about_area section_gap'>
      <div class='container'>
        <div class='row h_blog_item'>
          
          <div class='col-lg-12'> ";
           if(isset($_POST['cari'])){			
include "system/koneksi.php";


$login1=mysqli_query($kon, "select * from siswa where no_ujian='$_POST[no_ujian]'");
		$ketemu1=mysqli_num_rows($login1);
		$e=mysqli_fetch_array($login1);
	if ($ketemu1>0){
		
		if($e['verifikasi']==1){
			echo "
							
							<div class='col-sm-12'>
                <div class='alert  alert-danger alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-danger'>SELAMAT</span> ANDA SUDAH TERDAFTAR SEBAGAI SISWA SMA NEGERI 1 KALIWUNGU
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
            </div> ";
		}else{


echo "<script>;window.location='daftar2.php?hsfjhfs=$_POST[no_ujian]'</script>";								

		}				
						}else{
							echo "
							
							<div class='col-sm-12'>
                <div class='alert  alert-danger alert-dismissible fade show' role='alert'>
                  <span class='badge badge-pill badge-danger'>Error</span> DATA SISWA TIDAK DITEMUKAN! Pastikan nomer pendaftaran sudah benar
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
            </div> ";
						}
}			

					
echo"
        <div class='content mt-3'>

            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Cari Data Siswa Dengan Nomer Peserta</strong>
                      </div>
			<div class='card-body card-block'> 
 <form method='post' enctype='multipart/form-data' action='' class='form-horizontal'>
     <input name='cari' value='cari' hidden>	 
	 
					<div class='row form-group'>
                            <div class='col col-md-6'>
                              <div class='input-group'>
                                <input type='text' id='input2-group2' name='no_ujian' placeholder='Masukkan Nomer Peserta' class='form-control'>
                                <div class='input-group-btn'><button type='submit' class='btn btn-primary'>
                                    <i class='fa fa-search'></i> Search
                                  </button></div>
                              </div>
                            </div>
                          </div>			
			</div>		  
					  
                      
                      
                        </form>
                      </div>
                    </div>

        </div>
    </div>
          </div>
        </div>
      </div>
    </section>
    <!--================ End About Area =================-->

  </body>
  
  
  <script src='js/jquery-3.2.1.min.js'></script>
	<script src='js/popper.min.js'></script>
    <script src='js/plugins.js'></script>
	<script src='js/main1.js'></script>
	


	<script src='js/bootstrap.js' ></script>
  ";





?>