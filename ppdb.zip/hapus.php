<?php
  include "system/koneksi.php";
 $id = $_POST['id_anggota'];
 
 mysqli_query($kon, "delete from operator where id_operator='$id'")
										or die (mysqli_error() );
echo "<script>;window.location='admin.php?bagian=kjhdaskjhaseuhfdas786asdasdgjhads678dasg'</script>";								
?>