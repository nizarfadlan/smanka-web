<?php
include "system/koneksi.php";



mysqli_query($kon, "update siswa set alamat_sekolah='$_POST[alamat_sekolah]', tgl_lahir='$_POST[lahir]', tahun_ijasah='$_POST[tahun_ijasah]',
 tahun_skhun='$_POST[tahun_skhun]', telepon='$_POST[telepon]' ,kelas='$_POST[kelas]',no_ijasah='$_POST[no_ijasah]',no_skhun='$_POST[no_skhun]',
 agama='$_POST[agama]', anak_ke='$_POST[anak_ke]', status='$_POST[status]', ekstra2='$_POST[ekstra]', ekstra1='Pendidikan Kepramukaan'
 
 
 where no_ujian='$_POST[no_ujian]' ")
or die ("SQL Error: ".mysqli_error());


echo "<script>;window.location='cetakdata.php?sdfasfafasf=$_POST[no_ujian]'</script>";






?>