<?php
session_start();
include "system/koneksi.php";
include "system/tanggal2.php";
$resik=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[user]' ");
$k1=mysqli_fetch_array($resik);
 $operator=$_SESSION['user'];
 $wsql=mysqli_query($kon, "select * from operator where user='$operator' ");
$go=mysqli_fetch_array($wsql);
mysqli_query($kon, "update siswa set verifikasi='1' where no_ujian='$_GET[user]' ")
or die ("SQL Error: ".mysqli_error());
 $saatini=date('Y-m-d');
 

 echo "

  <link rel='stylesheet' href='css/surat.css'>
  <div class='bingkai'>
<div class='kotak'>
		<div class='kotak1'><img src='images/jateng.png' width='100px'></div>
		<div class='kotak2'>
				<div class='pemerintah'>PEMERINTAH PROVINSI JAWA TENGAH</div>
				<div class='dinas'>DINAS PENDIDIKAN DAN KEBUDAYAAN</div>
				<div class='sekolah'>SMA NEGERI 1 KALIWUNGU</div>
				<div class='alamat'>Jl. Pangeran Juminah - Kaliwungu - Kendal Telp. (0294) 382567</div>
				<div class='tambahan'>Surat Elektronik : smakaliwungu@yahoo.co.id http://www.sman1kaliwungu.sch.id</div>
		</div>
		
</div>


<hr>
<br>
<div class='judulsurat'> Tanda Bukti Daftar Ulang</div><br><br><br><br>
<div class='data'>
<table>
<tr><td>Nomor Pendaftaran </td><td> : </td><td>$k1[no_ujian]</td></tr>
<tr><td >Nama</td><td width='10px'> : </td><td>$k1[nama]</td></tr>


<tr><td>Tempat dan tanggal lahir </td><td> : </td><td>$k1[tempat], "; echo tanggalindo($k1['tgl_lahir']); echo "</td></tr>
<tr valign='top'><td>Alamat</td><td> : </td><td>$k1[alamat_pd]</td></tr>
<tr><td>Asal Sekolah </td><td> : </td><td>$k1[asal_sekolah]</td></tr>
<tr><td>Pilihan Ekstra 1 </td><td> : </td><td>$k1[ekstra1]</td></tr>
<tr><td>Pilihan Ekstra 2 </td><td> : </td><td>$k1[ekstra2]</td></tr>
</table>
<br><br><br>
<div class='judulsurat'> Jadwal Kegiatan</div><br>

</div>


<br>
<div class='data'>
 <table class='table table-bordered'>
 <tr><th>No</th><th>Tanggal</th><th>Jam</th><th>Pakaian</th><th>Kegiatan</th></tr>
  <tr><td>1. </td><td>12 Juli 2019</td><td>07:00 WIB </td><td>Pramuka</td><td>Pembekalan PLS (Pendidikan Lingkungan Sekolah), Rekam Finger Print dan Ukur Sepatu </td></tr>            
<tr valign='top'><td>2. </td><td>15 Juli 2019</td><td>06:30 WIB </td><td>OSIS SMP</td><td>Hari pertama masuk sekolah dan pembukaan MOPD </td></tr>  	
</table>		
			</div>
	<br><br><br>
<img src='code/$k1[no_ujian].png'>

<br><br><br>
<div class='tandatangan1'>
	Kaliwungu, "; echo tanggalindo($saatini); echo "  <br>
	Operator <br><br><br><br><br><br>
	<div class='kepsek'>( $go[nama] )</div>
	
	
	</div>
	
	</div><br><br><br><br><br><br>
	
</div>
<script>
window.print()
</script>
			";


?>