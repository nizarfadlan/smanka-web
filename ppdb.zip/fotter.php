<?php
echo "
<div class='footer'>
xgszgsdgs
</div>
";
?>