<?php

echo "
<footer>
	<div class='top-footer'>
		<div id='map' style='height: 10px;'></div>
	</div>
	<div class='zerogrid wrap-footer'>
		<div class='row'>
			<div class='col-2-4 col-footer-1'>
				<div class='wrap-col'>
					<h3 class='widget-title'>Tentang Kami</h3>
					<p>Dengan pelayanan yang baik dan secara online akan mempermudah dan memperbaiki pelayanan BKPP</p>
					<p>Lebih transparan dalam pelayanan bagian dari etos kerja kami</p>
					<ul class='quicklinks'>
						<li><a href='#'>Privacy Policy</a></li>
						<li><a href='#'>Terms of Use</a></li>
					</ul>
				</div>
			</div>
			<div class='col-1-4 col-footer-2'>
				<div class='wrap-col'>
					<h3 class='widget-title'>Hubungi Kami</h3>
										<strong style='font-size: 16px;'>(0294)381251 PESAWAT 258, 262 FAX. (0294)384750</strong>
					<p>Address:</p>
					<strong>JL. SOEKARNO - HATTA 193 KENDAL</strong>
					<p>Email:</p>
					<strong>bkpp@kendalkab.go.id</strong>
				</div>
			</div>
			<div class='col-1-4 col-footer-3'>
				<div class='wrap-col'>
					<h3 class='widget-title'>Socials</h3>
					<ul class='social-buttons'>
						<li><a href='#'><i class='fa fa-twitter'></i></a></li>
						<li><a href='#'><i class='fa fa-facebook'></i></a></li>
						<li><a href='#'><i class='fa fa-linkedin'></i></a></li>
						<li><a href='#'><i class='fa fa-pinterest'></i></a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class='bottom-footer'>
					<div class='copyright'>
						Copyright @ 2018 <a href='#'>BKPP Kendal</a>
					</div>
				</div>
	</div>
	
</footer>
";



?>