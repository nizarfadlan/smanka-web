<?php
	include "system/koneksi.php";
	include "system/tanggal2.php";
	$msqlw=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[sdfasfafasf]' ");
	$fr=mysqli_fetch_array($msqlw);
	
	$ayah=htmlentities($fr['ayah'],ENT_QUOTES);
	$ibu=htmlentities($fr['ibu'],ENT_QUOTES);
	$wali=htmlentities($fr['wali'],ENT_QUOTES);
echo "

 <head>
    <!-- Required meta tags -->
    <meta charset='utf-8' />
    <meta
      name='viewport'
      content='width=device-width, initial-scale=1, shrink-to-fit=no'
    />
    <link rel='icon' href='img/favicon.png' type='image/png' />
    <title>SMANKA</title>
     <link rel='stylesheet' href='csss/bootstrap.css' />
    
    <link rel='stylesheet' href='csss/style.css' />
  </head>
  <script type='text/javascript' src='js/jquery-3.2.1.min.js'></script> 

  <body>
   
    <!--================Home Banner Area =================-->
    <section class='banner_area'>
      <div class='banner_inner d-flex align-items-center'>
        <div class='overlay'></div>
        <div class='container'>
          <div class='row justify-content-center'>
            <div class='col-lg-6'>
              <div class='banner_content text-center'>
             
                <div class='page_link'>
               
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class='about_area section_gap'>
      <div class='container'>
        <div class='row h_blog_item'>
          
          
		  
	


            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Data Orang Tua </strong>
                      </div>
                     
						
						
						 <div class='card-body card-block'>
                        <form action='update5.php' method='post' class='form-horizontal' enctype='multipart/form-data'>
						<input type='text' name='no_ujian' value='$fr[no_ujian]' hidden>
						
						
						
						
						
                          <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama Ayah</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='ayah' value='$ayah' class='form-control'></div>
                          </div>
						  <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>NIK Ayah</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='nik_ayah' value='$fr[nik_ayah]' class='form-control'></div>
                          </div>
						  
						  <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Pekerjaan Ayah</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='kerja_ayah' value='$fr[kerja_ayah]' class='form-control'></div>
                          </div>
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama Ibu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='ibu' value='$ibu' class='form-control' ></div>
     </div>	
	  <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>NIK Ibu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='nik_ibu' value='$fr[nik_ibu]' class='form-control'></div>
                          </div>
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Pekerjaan Ibu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='kerja_ibu' value='$fr[kerja_ibu]' class='form-control'></div>
                          </div>


	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Telepon Ortu</label></div>
      <div class='col-12 col-md-9'><input type='text'  name='telepon_ortu' value='$fr[telepon_ortu]' class='form-control'></div>
     </div>
	<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Alamat Ortu</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='alamat_ortu' value='$fr[alamat_ortu]' class='form-control' ></div>
     </div>	
	 
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama Wali</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='wali' value='$wali' class='form-control' ></div>
     </div>	
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Pekerjaan Wali</label></div>
                            <div class='col-12 col-md-9'><input type='text'  name='kerja_wali' value='$fr[kerja_wali]' class='form-control'></div>
                          </div>


	<div class='row form-group'>
       <div class='col col-md-3'><label class=' form-control-label'>Alamat Wali </label></div>
      <div class='col-12 col-md-9'><input type='text'  name='alamat_wali' value='$fr[alamat_wali]' class='form-control'></div>
     </div>
	 
	 
  
		  
		  
		  
		  
		   </div>
                      <div class='card-footer'>
                        <button type='submit' class='btn btn-primary btn-sm'>
                          <i class='fa fa-save'></i> Lanjut
                        </button>
                        </form>
                      </div>
                    </div>
		  
		  
		  
		  
		  
		  
		  
        </div>
      </div>
    </section>
    <!--================ End About Area =================-->

  </body>
  ";





?>