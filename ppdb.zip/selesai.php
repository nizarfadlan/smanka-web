<?php
	include "system/koneksi.php";
	include "system/tanggal2.php";
	$msqlw=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[tsdysdg]' ");
	$ek=mysqli_fetch_array($msqlw);
	$no_ujian=$ek['no_ujian'];
echo "

 <head>
    <!-- Required meta tags -->
    <meta charset='utf-8' />
    <meta
      name='viewport'
      content='width=device-width, initial-scale=1, shrink-to-fit=no'
    />
    <link rel='icon' href='img/favicon.png' type='image/png' />
    <title>SMANKA</title>
     <link rel='stylesheet' href='csss/bootstrap.css' />
    
    <link rel='stylesheet' href='csss/style.css' />
	<link rel='stylesheet' href='css/font-awesome.min.css'>
    <link rel='stylesheet' href='css/style.css'> 
  </head>
  <script type='text/javascript' src='js/jquery-3.2.1.min.js'></script> 

  <body>
   
    <!--================Home Banner Area =================-->
    <section class='banner_area'>
      <div class='banner_inner d-flex align-items-center'>
        <div class='overlay'></div>
        <div class='container'>
          <div class='row justify-content-center'>
            <div class='col-lg-6'>
              <div class='banner_content text-center'>
                
                <div class='page_link'>
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class='about_area section_gap'>
      <div class='container'>
        <div class='row h_blog_item'>
          
          
		  
	


            <div class='col-sm-12'>
                
                 <div class='card'>
                      <div class='card-header'>
                        <strong>Cetak Bukti Daftar Ulang</strong>
                      </div>
					  
        <div class='row'>
				 <div class='col-sm-8'>              
			<div class='card-body card-block'>			
						<div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Nama</label></div>
                            <div class='col-12 col-md-9'><label>: $ek[nama]</label></div>
     </div>	
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Asal Sekolah</label></div>
                            <div class='col-12 col-md-9'><label>: $ek[asal_sekolah]</label></div>
     </div>
	 
	 <div class='row form-group'>
                            <div class='col col-md-3'><label class=' form-control-label'>Alamat</label></div>
                            <div class='col-12 col-md-9'><label>: $ek[alamat_pd]</label></div>
     </div>

</div>
				 </div>
				  <div class='col-sm-3'>
				  <div class='card-body card-block'>



<a href='cetak1.php?user=$no_ujian' target='_blank'>	
						<button type='button' class='btn btn-primary btn-sm'><i class='fa fa-print'></i> Cetak Bukti
                        </button></a>








				  
				 
				  </div>
			</div>
		  </div>
		<div class='col-sm-12'>  
		<b> Lakukan cetak dan bawa hasil cetakan ke SMAN 1 KALIWUNGU tanggal 12 Juli 2019 sebagai syarat daftar ulang </b>  
		  </div>
		  
		  
		  
        </div>
      </div>
    </section>
    <!--================ End About Area =================-->

  </body>
  ";





?>