<?php
include "system/koneksi.php";
$mapel=$_POST['kirim'];
$ekstra=mysqli_query($kon, "select * from ekstra where nama_ekstra='$mapel' ");
$w=mysqli_fetch_array($ekstra);
echo "
<table id='bootstrap-data-table' class='table table-striped table-bordered'>
                    <thead>

		<tr><th>Nama Ekstra</th><th>Hari</th><th>Pembina</th></tr>
				</thead> 
				<tbody>
				<tr><td>$w[nama_ekstra]</td><td>$w[hari]</td><td>$w[pembina]</td></tr>
				
			 </tbody>   
            </table>

";
?>