<?php
session_start();
include "system/koneksi.php";
include "system/tanggal2.php";
$resik=mysqli_query($kon, "select * from siswa where no_ujian='$_GET[user]' ");
$k1=mysqli_fetch_array($resik);
 $saatini=date('Y-m-d');
 echo "

  <link rel='stylesheet' href='css/surat2.css'>

  <div class='bingkai'>
<div class='kotak'>
		<div class='kotak1'><img src='images/jateng.png' width='100px'></div>
		<div class='kotak2'>
				<div class='pemerintah'>PEMERINTAH PROVINSI JAWA TENGAH</div>
				<div class='dinas'>DINAS PENDIDIKAN DAN KEBUDAYAAN</div>
				<div class='sekolah'>SMA NEGERI 1 KALIWUNGU</div>
				<div class='alamat'>Jl. Pangeran Juminah - Kaliwungu - Kendal Telp. (0294) 382567</div>
				<div class='tambahan'>Surat Elektronik : smakaliwungu@yahoo.co.id http://www.sman1kaliwungu.sch.id</div>
		</div>
		
</div>


<hr>
<br>
<div class='judulsurat'> IDENTITAS PESERTA DIDIK</div><br><br>
<div class='pasfoto1'> Pasfoto 3x4 waktu meninggalkan sekolah ini dan tiga sidik jari kiri
</div>
<div class='pasfoto2'> Pasfoto 3x4 waktu meninggalkan sekolah ini dan tiga sidik jari kiri
</div>
<table>
<tr><td>1. </td><td width='190px'>Nama Peserta didik (lengkap)</td><td width='10px'> : </td><td>$k1[nama]</td></tr>
<tr><td>2. </td><td>Nomor induk / NISN </td><td> : </td><td>$k1[nisn]</td></tr>
<tr><td>3. </td><td>Jenis kelamin </td><td> : </td><td>$k1[jk]</td></tr>
<tr><td>4. </td><td>Tempat dan tanggal lahir </td><td> : </td><td>$k1[tempat], "; echo tanggalindo($k1['tgl_lahir']); echo "</td></tr>
<tr><td>5. </td><td>Agama </td><td> : </td><td>$k1[agama]</td></tr>
<tr><td>6. </td><td>Anak Ke </td><td> : </td><td>$k1[anak_ke]</td></tr>
<tr><td>7. </td><td>Status dalam keluarga </td><td> : </td><td>$k1[status]</td></tr>
<tr valign='top'><td>8. </td><td >Alamat peserta didik </td><td> : </td><td>$k1[alamat_pd]</td></tr>
<tr><td> </td><td>telepon </td><td> : </td><td>$k1[telepon]</td></tr>
<tr><td>9. </td><td>Diterima di sekolah ini </td><td></td><td></td></tr>
<tr><td> </td><td>a. Di kelas </td><td> : </td><td>X </td></tr>
<tr><td> </td><td>b. Pada tanggal </td><td> : </td><td>15 Juli 2019</td></tr>
<tr><td> </td><td>c. Semester </td><td> : </td><td>1</td></tr>
<tr><td>10. </td><td>Sekolah asal </td><td></td><td></td></tr>
<tr><td> </td><td>a. Nama sekolah </td><td> : </td><td>$k1[asal_sekolah]</td></tr>
<tr valign='top'><td> </td><td>b. Alamat </td><td> : </td><td>$k1[alamat_sekolah]</td></tr>
<tr><td>11. </td><td>Ijazah SMP / MTs </td><td>  </td><td></td></tr>
<tr><td> </td><td>a. Tahun </td><td> : </td><td>$k1[tahun_ijasah]</td></tr>
<tr><td> </td><td>b. Nomor </td><td> : </td><td></td></tr>
<tr><td>12. </td><td colspan='3'>Surat Keterangan Hasil Ujian Nasional (SKHUN) SMP / MTs, Paket B (diusulkan) </td></tr>
<tr><td> </td><td>a. Tahun </td><td> : </td><td>$k1[tahun_skhun]</td></tr>
<tr><td> </td><td>b. Nomor </td><td> : </td><td></td></tr>
<tr><td>13. </td><td colspan='3'>Nama orang tua </td></tr>
<tr><td> </td><td>a. Ayah </td><td> : </td><td>$k1[ayah]</td></tr>
<tr><td> </td><td>b. Ibu </td><td> : </td><td>$k1[ibu]</td></tr>
<tr valign='top'><td>14. </td><td>Alamat orang tua </td><td> : </td><td>$k1[alamat_ortu]</td></tr>
<tr><td> </td><td>telepon </td><td> : </td><td>$k1[telepon_ortu]</td></tr>
<tr><td>15. </td><td>Pekerjaan orang tua </td><td>  </td><td></td></tr>
<tr><td> </td><td>a. Ayah </td><td> : </td><td>$k1[kerja_ayah]</td></tr>
<tr><td> </td><td>b. Ibu </td><td> : </td><td>$k1[kerja_ibu]</td></tr>
<tr><td>16. </td><td>Nama wali </td><td> : </td><td>$k1[wali]</td></tr>
<tr valign='top'><td>17. </td><td>Alamat wali </td><td> : </td><td>$k1[alamat_wali]</td></tr>
<tr><td>18. </td><td>Pekerjaan wali </td><td> : </td><td>$k1[kerja_wali]</td></tr>
<tr><td> </td><td>telepon </td><td> : </td><td>-</td></tr>
<tr><td>19. </td><td colspan='3'>Mutasi </td></tr>
<tr><td> </td><td>a. Pindahan ke </td><td> : </td><td>-</td></tr>
<tr><td> </td><td>b. Pindahan dari </td><td> : </td><td>-</td></tr>
</table>



<br><br><br><br><br><br><br><br><br><br>


<div class='bingkai'>
<div class='kotak'>
		<div class='kotak1'><img src='images/jateng.png' width='100px'></div>
		<div class='kotak2'>
				<div class='pemerintah'>PEMERINTAH PROVINSI JAWA TENGAH</div>
				<div class='dinas'>DINAS PENDIDIKAN DAN KEBUDAYAAN</div>
				<div class='sekolah'>SMA NEGERI 1 KALIWUNGU</div>
				<div class='alamat'>Jl. Pangeran Juminah - Kaliwungu - Kendal Telp. (0294) 382567</div>
				<div class='tambahan'>Surat Elektronik : smakaliwungu@yahoo.co.id http://www.sman1kaliwungu.sch.id</div>
	
		</div>
		
</div>

</div>
<hr>
<br>
<div class='judulsurat'> Form Pilihan Ekstra Kulikuler</div><br><br>

<br>

<table>
<tr><td>Nomor Pendaftaran</td><td width='10px'> : </td><td>$k1[no_ujian]</td></tr>
<tr><td width='190px'>Nama </td><td> : </td><td>$k1[nama]</td></tr>
<tr><td>Tempat dan tanggal lahir </td><td> : </td><td>$k1[tempat], "; echo tanggalindo($k1['tgl_lahir']); echo "</td></tr>
<tr valign='top'><td>Alamat </td><td> : </td><td>$k1[alamat_pd]</td></tr>
<tr><td>Asal Sekolah </td><td> : </td><td>$k1[asal_sekolah]</td></tr>
<tr><td>Pilihan Ekstra 1 </td><td> : </td><td>$k1[ekstra1]</td></tr>
<tr><td>Pilihan Ekstra 2 </td><td> : </td><td>$k1[ekstra2]</td></tr>
</table>
<br>

<br><br><br>
<img src='code/$k1[no_ujian].png'>

<br><br><br>
<div class='tandatangan1'>
	Kaliwungu, "; echo tanggalindo($saatini); echo "  <br>
	Calon Peserta Didik <br><br><br><br><br><br>
	<div class='kepsek'>( $k1[nama] )</div>
	
	
	</div>






</div>

<script>
window.print()
</script>
			";


?>