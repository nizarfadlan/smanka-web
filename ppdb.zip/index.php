<?php

echo "
 <head>
    <!-- Required meta tags -->
    <meta charset='utf-8' />
    <meta
      name='viewport'
      content='width=device-width, initial-scale=1, shrink-to-fit=no'
    />
    <link rel='icon' href='img/favicon.png' type='image/png' />
    <title>SMANKA</title>
     <link rel='stylesheet' href='csss/bootstrap.css' />
    
    <link rel='stylesheet' href='csss/style.css' />
  </head>

  <body>
   
    <!--================Home Banner Area =================-->
    <section class='banner_area'>
      <div class='banner_inner d-flex align-items-center'>
        <div class='overlay'></div>
        <div class='container'>
          <div class='row justify-content-center'>
            <div class='col-lg-6'>
              <div class='banner_content text-center'>
               
                <div class='page_link'>

                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
 <section class='about_area section_gap'>
      <div class='container'>
      
          
          <div class='col-lg-12'>
            <div class='h_blog_text'>
              <div class='h_blog_text_inner left right'>
                <h4>Jadwal Kegiatan Siswa Baru</h4>
                <p>
				 <table id='bootstrap-data-table' class='table table-striped table-bordered'>
                    <thead>
					<tr><th>Hari, 12 Juli 2019</th><th>Jam</th><th>Kegiatan</th></tr>
					<tr><td>Jumat</td><td>07:00 - 11:00</td><td>1. Pemaparan Visi Misi sekolah untuk siswa dan orang tua. <br>
					2. Penanda tanganan fakta integritas dan tata tertib. <br>
					3. Gladi bersih MPLS (Masa Pengenalan Lingkungan Sekolah). <br>
					
					
					</thead>
				</table>
                </p>
               
              </div>
            </div>
          </div>
        
      </div>
    </section>
	
	
    <section class='about_area section_gap'>
      <div class='container'>
        <div class='row h_blog_item'>
          <div class='col-lg-6'>
            <div class='h_blog_img'>
              <img class='img-fluid' src='img/about.png' alt='' />
            </div>
          </div>
          <div class='col-lg-6'>
            <div class='h_blog_text'>
              <div class='h_blog_text_inner left right'>
                <h4>Prosedur Daftar Ulang</h4>
                <p>
				<b>Selamat bergabung sebagai siswa SMAN 1 Kaliwungu.</b>
				  Mulailah daftar ulang dengan mengisi form, lakukan cetak dan
				  di bawa ke SMAN 1 Kaliwungu untuk verifikasi data daftar ulang.
                </p>
                <p>
                  Jika tidak melakukan daftar ulang maka dianggap mengundurkan diri dan digugurkan
				  sebaga siswa SMAN 1 Kaliwungu.
                </p>
                <a class='primary-btn' href='daftar.php'>
                 Mulai Daftar Ulang <i class='ti-arrow-right ml-1'></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--================ End About Area =================-->

  </body>
  ";





?>